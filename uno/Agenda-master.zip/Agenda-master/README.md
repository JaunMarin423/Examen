# Agenda
Agenda de Contactos realizado utilizando Angular.js

Este código consiste en una Agenda de Contactos implementada en Angular.js. Con ella pretendía realizar una aplicación fácil y utilizable para aprender este lenguaje basado en JavaScript. 
Con ella podemos añadir nuevos contactos, añadiendo su nombre, número de telefono y dirección y tenerlos visibles cuando abrimos el .html en nuestro navegador.
